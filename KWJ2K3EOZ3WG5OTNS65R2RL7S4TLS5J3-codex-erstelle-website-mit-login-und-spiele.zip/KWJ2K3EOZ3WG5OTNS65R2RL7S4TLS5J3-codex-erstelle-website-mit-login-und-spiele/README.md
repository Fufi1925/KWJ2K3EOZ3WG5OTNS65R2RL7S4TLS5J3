# Orendor Glass Arcade

Moderne Website mit:

- schwarzem Glassmorphism Login
- erfolgreichem Login und Zugriff auf 100+ Online-Spiele
- moderner persistenter JSON-Datenbank

## Start

```bash
npm start
```

Dann öffnen: `http://localhost:3000`

## Demo Login

- E-Mail: `demo@arcade.com`
- Passwort: `Demo1234!`
